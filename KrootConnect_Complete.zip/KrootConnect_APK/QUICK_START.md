# 🚀 البدء السريع - كروت كونكت الأوتوماتيكية

## 📍 موقع المشروع

```
/home/ubuntu/KrootConnectApp
```

---

## ⚡ خطوات البدء السريعة

### 1️⃣ فتح المشروع في Android Studio

```bash
# الذهاب إلى مجلد المشروع
cd /home/ubuntu/KrootConnectApp

# فتح في Android Studio
open -a "Android Studio" .
```

أو يدويًا:
- افتح Android Studio
- اختر File → Open
- اختر `/home/ubuntu/KrootConnectApp`

### 2️⃣ بناء التطبيق

```bash
# بناء التطبيق
./gradlew build

# بناء ملف APK (Release)
./gradlew assembleRelease

# بناء ملف APK (Debug)
./gradlew assembleDebug
```

### 3️⃣ تثبيت على جهاز

```bash
# تثبيت على جهاز متصل
./gradlew installDebug

# تشغيل التطبيق
./gradlew runDebug
```

---

## 📁 الملفات المهمة

| الملف | الوصف |
|------|-------|
| `README.md` | نظرة عامة على المشروع |
| `USAGE_GUIDE.md` | دليل الاستخدام الشامل |
| `TECHNICAL_GUIDE.md` | الدليل التقني للمطورين |
| `PROJECT_SUMMARY.md` | ملخص المشروع |
| `QUICK_START.md` | هذا الملف |

---

## 🎯 الميزات الرئيسية

✅ أتمتة الرد على رسائل SMS  
✅ تحليل ذكي للرسائل  
✅ إدارة الكروت بفئات (100، 200، 300، 500)  
✅ لوحة تحكم متقدمة  
✅ نظام سجلات شامل  
✅ إشعارات ذكية  
✅ أمان عالي للبيانات  

---

## 📱 الفئات السعرية

- 100 ر.ي
- 200 ر.ي
- 300 ر.ي
- 500 ر.ي

---

## 🔐 الأذونات المطلوبة

- RECEIVE_SMS
- SEND_SMS
- READ_SMS
- READ_CONTACTS
- POST_NOTIFICATIONS

---

## 🛠️ المتطلبات

- Android Studio 4.0+
- JDK 11+
- Android SDK 21+
- Gradle 7.0+

---

## 📊 إحصائيات المشروع

- **ملفات Java**: 15
- **ملفات XML**: 12
- **أسطر الكود**: ~3,500+
- **حجم التطبيق**: ~50 MB

---

## 🎨 التصميم

- ألوان عصرية وزاهية
- واجهة سلسة وسهلة الاستخدام
- تدرجات لونية جميلة
- بطاقات مستديرة وظلال ناعمة

---

## 📞 الدعم

للمزيد من المعلومات، اقرأ:
- README.md
- USAGE_GUIDE.md
- TECHNICAL_GUIDE.md

---

**آخر تحديث**: 2024
