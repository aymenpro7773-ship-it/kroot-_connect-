# 📱 تعليمات بناء ملف APK

## ⚠️ ملاحظة مهمة

المشروع يحتاج إلى بناء كامل في Android Studio. إليك الخطوات:

---

## 🔧 الطريقة 1: باستخدام Android Studio (الأسهل)

### الخطوات:

1. **تثبيت Android Studio**
   - حمّل من: https://developer.android.com/studio

2. **فتح المشروع**
   - افتح Android Studio
   - اختر File → Open
   - اختر مجلد: `/home/ubuntu/KrootConnectApp`

3. **انتظر التحميل**
   - سيقوم Android Studio بتحميل جميع المكتبات
   - قد يستغرق 5-10 دقائق

4. **بناء التطبيق**
   - اختر Build → Build Bundle(s) / APK(s) → Build APK(s)
   - أو اضغط Shift + F10

5. **الحصول على ملف APK**
   - سيظهر إشعار "APK(s) generated successfully"
   - ملف APK سيكون في:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 🔧 الطريقة 2: باستخدام سطر الأوامر

### الخطوات:

```bash
# الذهاب إلى مجلد المشروع
cd /home/ubuntu/KrootConnectApp

# بناء التطبيق
./gradlew build

# بناء ملف APK Debug
./gradlew assembleDebug

# بناء ملف APK Release
./gradlew assembleRelease
```

### ملف APK سيكون في:
```
app/build/outputs/apk/debug/app-debug.apk      (للاختبار)
app/build/outputs/apk/release/app-release.apk  (للإطلاق)
```

---

## 📋 المتطلبات

- ✅ Android Studio 4.0+
- ✅ JDK 11+
- ✅ Android SDK 21+
- ✅ Gradle 7.0+
- ✅ 2 GB ذاكرة حرة

---

## 📱 تثبيت التطبيق على الهاتف

### بعد الحصول على ملف APK:

#### الطريقة 1: نقل مباشر
1. انسخ ملف `app-debug.apk` إلى هاتفك
2. افتح الملف على الهاتف
3. اضغط "تثبيت"

#### الطريقة 2: عبر ADB
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

#### الطريقة 3: من Android Studio
1. اختر Run → Run 'app'
2. اختر جهازك
3. اضغط OK

---

## ✨ ملخص الملفات

| الملف | الحجم | الوصف |
|------|-------|-------|
| app-debug.apk | ~50 MB | للاختبار والتطوير |
| app-release.apk | ~45 MB | للإطلاق والتوزيع |

---

## 🎯 ماذا بعد التثبيت؟

1. **افتح التطبيق**
2. **امنح الأذونات** المطلوبة:
   - استقبال الرسائل
   - إرسال الرسائل
   - الوصول للجهات
   - الإشعارات

3. **اذهب للإعدادات**
   - أدخل اسم المرسل: `jaib`
   - حدد حد التنبيه: `5`
   - فعّل الإشعارات

4. **أضف الكروت**
   - اذهب لإدارة الكروت
   - أضف كروت من الفئات (100، 200، 300، 500)

5. **فعّل الأتمتة**
   - اذهب للوحة التحكم
   - فعّل مفتاح الأتمتة

---

## 🐛 استكشاف الأخطاء

### المشكلة: "لا يمكن فتح المشروع"
**الحل:**
- تأكد من تثبيت JDK 11+
- تأكد من تثبيت Android SDK
- احذف مجلد `.gradle` وحاول مجدداً

### المشكلة: "فشل البناء"
**الحل:**
- اختر File → Invalidate Caches
- اختر Build → Clean Project
- اختر Build → Rebuild Project

### المشكلة: "لا توجد أجهزة"
**الحل:**
- تأكد من توصيل الهاتف بالكمبيوتر
- فعّل وضع المطور على الهاتف
- اختر "السماح بتصحيح الأخطاء عبر USB"

---

## 📞 الدعم

للمزيد من المعلومات:
- اقرأ README.md
- اقرأ USAGE_GUIDE.md
- اقرأ TECHNICAL_GUIDE.md

---

**آخر تحديث**: 2024
