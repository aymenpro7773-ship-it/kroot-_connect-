# الدليل التقني - كروت كونكت الأوتوماتيكية

## نظرة عامة على المشروع

هذا المستند يوضح البنية المعمارية والتقنية للتطبيق للمطورين والمهتمين بفهم الكود.

---

## 1. بنية المشروع

```
KrootConnectApp/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/kroot/connect/
│   │       │   ├── MainActivity.java
│   │       │   ├── database/
│   │       │   │   ├── AppDatabase.java
│   │       │   │   ├── dao/
│   │       │   │   │   ├── CardDao.java
│   │       │   │   │   └── TransactionLogDao.java
│   │       │   │   └── entity/
│   │       │   │       ├── CardEntity.java
│   │       │   │       └── TransactionLogEntity.java
│   │       │   ├── receivers/
│   │       │   │   └── SmsReceiver.java
│   │       │   ├── services/
│   │       │   │   └── SmsProcessingService.java
│   │       │   ├── ui/
│   │       │   │   ├── DashboardActivity.java
│   │       │   │   ├── CardsManagementActivity.java
│   │       │   │   ├── LogsActivity.java
│   │       │   │   └── SettingsActivity.java
│   │       │   └── utils/
│   │       │       ├── SmsMessageParser.java
│   │       │       ├── PreferencesManager.java
│   │       │       └── NotificationHelper.java
│   │       ├── res/
│   │       │   ├── layout/
│   │       │   ├── values/
│   │       │   ├── drawable/
│   │       │   └── menu/
│   │       └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## 2. المكونات الرئيسية

### 2.1 قاعدة البيانات (Database Layer)

#### AppDatabase.java
- **الدور**: مركز إدارة قاعدة البيانات
- **النمط**: Singleton
- **المكتبة**: Room Database
- **الجداول**: 
  - `cards`: تخزين الكروت
  - `transaction_logs`: تسجيل العمليات

```java
@Database(
    entities = {CardEntity.class, TransactionLogEntity.class},
    version = 1,
    exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {
    public abstract CardDao cardDao();
    public abstract TransactionLogDao transactionLogDao();
}
```

#### CardEntity.java
- **الحقول**:
  - `id`: المعرف الفريد
  - `cardCode`: كود الكرت
  - `category`: الفئة السعرية (100، 200، 300، 500)
  - `status`: الحالة (available/used)
  - `createdAt`: تاريخ الإنشاء
  - `usedAt`: تاريخ الاستخدام
  - `usedByNumber`: رقم العميل الذي استخدم الكرت

#### TransactionLogEntity.java
- **الحقول**:
  - `id`: المعرف الفريد
  - `timestamp`: وقت العملية
  - `amount`: المبلغ
  - `customerNumber`: رقم العميل
  - `cardCode`: كود الكرت المرسل
  - `status`: حالة العملية (success/failed/pending)
  - `originalMessage`: الرسالة الأصلية
  - `errorMessage`: رسالة الخطأ إن وجدت

### 2.2 طبقة الوصول إلى البيانات (DAO)

#### CardDao.java
- عمليات CRUD للكروت
- استعلامات متخصصة:
  - `getAvailableCardByCategory()`: الحصول على كرت متاح
  - `getAvailableCardsCount()`: عد الكروت المتاحة
  - `getUsedCardsCount()`: عد الكروت المستخدمة

#### TransactionLogDao.java
- عمليات CRUD للسجلات
- استعلامات متخصصة:
  - `getDailySales()`: المبيعات اليومية
  - `getMonthlySales()`: المبيعات الشهرية
  - `getLogsByStatus()`: السجلات حسب الحالة

---

## 3. معالجة الرسائل (SMS Processing)

### 3.1 SmsReceiver.java
```
BroadcastReceiver
    ↓
استقبال رسائل SMS
    ↓
استخراج البيانات من PDU
    ↓
بدء SmsProcessingService
```

**الخطوات**:
1. استقبال البث عند وصول رسالة SMS
2. التحقق من تفعيل الأتمتة
3. استخراج بيانات الرسالة
4. إرسال الرسالة إلى الخدمة

### 3.2 SmsProcessingService.java
```
SmsProcessingService
    ↓
تحليل الرسالة (SmsMessageParser)
    ↓
البحث عن كرت متاح
    ↓
إرسال الكرت (SmsManager)
    ↓
تحديث قاعدة البيانات
    ↓
إرسال إشعار
```

**الخطوات**:
1. تحليل الرسالة واستخراج المبلغ والرقم
2. البحث عن كرت متاح من الفئة المطلوبة
3. إرسال الكرت عبر SMS
4. تحديث حالة الكرت إلى "مستخدم"
5. تسجيل العملية في قاعدة البيانات
6. إرسال إشعار للمستخدم

---

## 4. تحليل الرسائل (SMS Parser)

### SmsMessageParser.java

#### extractAmount(String message)
```
البحث عن الأنماط:
1. "أضيف 100ر.ي" → 100
2. "تم إضافة 200" → 200
3. "المبلغ 300" → 300
4. "**500**" → 500
    ↓
التحقق من صحة الفئة (100, 200, 300, 500)
    ↓
إرجاع المبلغ أو null
```

#### extractCustomerNumber(String message)
```
البحث عن الأنماط:
1. "من 912345678" → 912345678
2. "رقم 912345678" → 912345678
3. أي رقم بـ 8 أرقام فأكثر
    ↓
تنظيف الرقم (إزالة الأحرف غير الرقمية)
    ↓
إرجاع الرقم أو null
```

#### isValidCategory(int amount)
```
التحقق من أن المبلغ ينتمي إلى:
- 100 ✓
- 200 ✓
- 300 ✓
- 500 ✓
- غير ذلك ✗
```

#### analyzeSms(String message, String senderAddress, String expectedSender)
```
التحقق من المرسل
    ↓
التحقق من الكلمات الأساسية
    ↓
استخراج البيانات
    ↓
إرجاع SmsAnalysisResult
```

---

## 5. إدارة الإعدادات

### PreferencesManager.java
- **النمط**: Singleton
- **التخزين**: SharedPreferences
- **البيانات المحفوظة**:
  - `automation_enabled`: حالة الأتمتة
  - `sender_name`: اسم المرسل المتوقع
  - `response_message`: رسالة الرد
  - `low_stock_threshold`: حد التنبيه المنخفض
  - `notifications_enabled`: تفعيل الإشعارات
  - `notification_sound`: صوت الإشعار
  - `notification_vibration`: اهتزاز الإشعار

```java
PreferencesManager prefs = PreferencesManager.getInstance(context);
boolean isEnabled = prefs.isAutomationEnabled();
prefs.setAutomationEnabled(true);
```

---

## 6. نظام الإشعارات

### NotificationHelper.java

#### createNotificationChannels()
```
Android 8.0+ يتطلب قنوات إشعارات
    ↓
إنشاء 3 قنوات:
1. CHANNEL_ID_SUCCESS (النجاح)
2. CHANNEL_ID_ERROR (الأخطاء)
3. CHANNEL_ID_WARNING (التحذيرات)
```

#### showNotification(Context, String title, String message)
```
التحقق من تفعيل الإشعارات
    ↓
تحديد نوع الإشعار
    ↓
إنشاء Intent للنشاط الرئيسي
    ↓
إضافة الصوت والاهتزاز إذا كانا مفعلين
    ↓
عرض الإشعار
```

---

## 7. الواجهات (UI Activities)

### MainActivity.java
- **الدور**: النشاط الرئيسي
- **المسؤوليات**:
  - طلب الأذونات
  - إعداد التنقل السفلي
  - إنشاء قنوات الإشعارات

### DashboardActivity.java
- **الدور**: لوحة التحكم
- **العناصر**:
  - مفتاح تفعيل/تعطيل الأتمتة
  - إحصائيات المبيعات اليومية والشهرية
  - عداد العمليات

### CardsManagementActivity.java
- **الدور**: إدارة الكروت
- **الميزات**:
  - إضافة يدوية (نسخ واللصق)
  - استيراد من ملف
  - عرض قائمة الكروت

### LogsActivity.java
- **الدور**: عرض السجلات
- **الميزات**:
  - عرض جميع العمليات
  - تصفية حسب الحالة
  - عرض التفاصيل

### SettingsActivity.java
- **الدور**: الإعدادات
- **الخيارات**:
  - اسم المرسل
  - رسالة الرد
  - حد التنبيه المنخفض
  - إعدادات الإشعارات

---

## 8. تدفق العمل الكامل

```
1. استقبال الرسالة
   ↓
2. SmsReceiver.onReceive()
   ↓
3. بدء SmsProcessingService
   ↓
4. SmsMessageParser.analyzeSms()
   - استخراج المبلغ
   - استخراج رقم العميل
   - التحقق من الصحة
   ↓
5. البحث عن كرت متاح
   CardDao.getAvailableCardByCategory()
   ↓
6. إرسال الكرت
   SmsManager.sendTextMessage()
   ↓
7. تحديث قاعدة البيانات
   - تحديث حالة الكرت
   - إدراج سجل العملية
   ↓
8. إرسال إشعار
   NotificationHelper.showNotification()
   ↓
9. التحقق من المخزون المنخفض
   checkLowStockAlert()
```

---

## 9. المكتبات المستخدمة

| المكتبة | الإصدار | الاستخدام |
|--------|--------|----------|
| AndroidX | 1.6.1+ | مكتبات الدعم الحديثة |
| Material Design | 1.10.0 | تصميم عصري |
| Room Database | 2.6.0 | قاعدة البيانات |
| Lifecycle | 2.6.2 | إدارة دورة الحياة |
| GSON | 2.10.1 | معالجة JSON |
| Security Crypto | 1.1.0 | تشفير البيانات |

---

## 10. الأمان والخصوصية

### تشفير البيانات
- استخدام `EncryptedSharedPreferences` للبيانات الحساسة
- تخزين الكروت في قاعدة بيانات محلية

### إدارة الأذونات
```xml
<uses-permission android:name="android.permission.RECEIVE_SMS" />
<uses-permission android:name="android.permission.SEND_SMS" />
<uses-permission android:name="android.permission.READ_SMS" />
<uses-permission android:name="android.permission.READ_CONTACTS" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

### حماية البيانات
- عدم تخزين كلمات المرور
- حذف السجلات القديمة تلقائياً
- عدم مشاركة البيانات مع تطبيقات أخرى

---

## 11. الاختبار والتصحيح

### اختبار الوحدة (Unit Tests)
```java
// اختبار SmsMessageParser
@Test
public void testExtractAmount() {
    Integer amount = SmsMessageParser.extractAmount("أضيف 100ر.ي");
    assertEquals(100, amount.intValue());
}

@Test
public void testValidCategory() {
    assertTrue(SmsMessageParser.isValidCategory(100));
    assertTrue(SmsMessageParser.isValidCategory(200));
    assertFalse(SmsMessageParser.isValidCategory(150));
}
```

### اختبار التكامل (Integration Tests)
```java
// اختبار قاعدة البيانات
@Test
public void testInsertCard() {
    CardEntity card = new CardEntity("CARD001", 100);
    long id = cardDao.insertCard(card);
    assertTrue(id > 0);
}
```

---

## 12. الأداء والتحسينات

### تحسينات الأداء:
1. استخدام Threads للعمليات الطويلة
2. استخدام LiveData للتحديثات التلقائية
3. تخزين مؤقت للبيانات المتكررة
4. حذف السجلات القديمة دورياً

### استهلاك الموارد:
- **الذاكرة**: ~50 MB
- **التخزين**: ~10 MB
- **البطارية**: منخفضة (لا توجد عمليات مستمرة)

---

## 13. التطوير المستقبلي

### ميزات مخططة:
- [ ] دعم لغات متعددة
- [ ] تقارير متقدمة
- [ ] مزامنة سحابية
- [ ] واجهة ويب للإدارة
- [ ] API للتكامل مع أنظمة أخرى

### التحسينات المقترحة:
- [ ] تحسين دقة تحليل الرسائل
- [ ] دعم أنماط رسائل مختلفة
- [ ] إضافة نسخ احتياطية تلقائية
- [ ] تحليلات متقدمة

---

## 14. استكشاف الأخطاء

### تفعيل وضع التصحيح:
```java
// إضافة في MainActivity
if (BuildConfig.DEBUG) {
    Log.d("DEBUG", "وضع التصحيح مفعل");
}
```

### عرض السجلات:
```bash
adb logcat | grep "SmsReceiver\|SmsProcessingService"
```

### اختبار الرسائل:
```bash
adb shell am broadcast -a android.provider.Telephony.SMS_RECEIVED \
  --es pdus "0123456789"
```

---

## 15. نصائح للمطورين

### إضافة ميزة جديدة:
1. أنشئ فئة جديدة في المجلد المناسب
2. أضف الواجهات اللازمة (Interfaces)
3. اكتب اختبارات الوحدة
4. حدّث الوثائق
5. اختبر التكامل مع باقي التطبيق

### تعديل قاعدة البيانات:
1. عدّل الكيان (Entity)
2. حدّث DAOs
3. زيادة رقم الإصدار (version)
4. اكتب Migration إذا لزم الأمر

### إضافة إذن جديد:
1. أضفه في AndroidManifest.xml
2. طلبه في MainActivity
3. تعامل مع حالة الرفض

---

**آخر تحديث**: 2024

للمزيد من المعلومات، راجع الكود المصدري والتعليقات في الملفات.
